import java.io.*;
import java.net.*;
import java.util.*;

public class Reverse_Client
{
	public static void main(String args[])
	{
		String servername = args[0];
		int port = Integer.parseInt(args[1]);
		try
		{
			System.out.println("Connecting to server "+servername+" ar port no:"+port);
			Socket client = new Socket(servername,port);
			System.out.println("Connected to server at "+client.getRemoteSocketAddress());
			InputStream inFromServer = client.getInputStream();
			DataInputStream in = new DataInputStream(inFromServer);
			OutputStream outToServer = client.getOutputStream();
			DataOutputStream out = new DataOutputStream(outToServer);
			Scanner input = new Scanner(System.in);
			System.out.println("Enter the String");
			String inp = input.next();
			out.writeUTF(""+inp);
			String rev=in.readUTF();
			System.out.println("Entered String :"+inp+"\tReverse String :"+rev);
			client.close();	
		}
		catch(IOException e){}
	}
}
