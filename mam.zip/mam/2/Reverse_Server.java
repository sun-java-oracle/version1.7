import java.io.*;
import java.net.*;

public class Reverse_Server extends Thread
{
	private ServerSocket serversocket;
	public Reverse_Server(int port)throws IOException
	{
		serversocket = new ServerSocket(port);
		serversocket.setSoTimeout(10000);
	}
	
	public void run()
	{
		while(true)
		{
			try
			{
				System.out.println("Waiting for connection at port :"+serversocket.getLocalPort());
				Socket server = serversocket.accept();
				System.out.println("Connected to client "+server.getRemoteSocketAddress());
				DataInputStream in = new DataInputStream(server.getInputStream());
				DataOutputStream out = new DataOutputStream(server.getOutputStream());
				String inp=in.readUTF();
				String reverse = new StringBuffer(inp).reverse().toString();
				out.writeUTF(""+reverse);
			}
			catch(IOException e){break;}
		}
	}
	
	public static void main(String args[])
	{
		int port=Integer.parseInt(args[0]);
		try
		{
			Thread t = new Reverse_Server(port);
			t.start();
		}
		catch(IOException e){}
	}
}
