#include <mpi.h>
#include <stdio.h>
#include<string.h>
#include<stdlib.h>
char * strrev(char * str)
{
	char p1[strlen(str)];
	int i;
	for(i=0;i<strlen(str);i++)
		p1[i]=str[strlen(str)-i-1];
	p1[strlen(str)]='\0';
	str =p1;
	return str;
}
int main(int argc,char**argv)
{

	MPI_Comm client;
	MPI_Status status;
	int size;
	char port_name[MPI_MAX_PORT_NAME];
	char msg[1024];

	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD,&size);
	if(size!=1)
	{
		printf("Server too big");
		exit(1);
	}
	MPI_Open_port(MPI_INFO_NULL,port_name);
	printf("Server available at %s\n",port_name);
	while(1)
	{
		MPI_Comm_accept(port_name,MPI_INFO_NULL,0,MPI_COMM_WORLD,&client);
		while(1)
		{
			MPI_Recv(msg,1024,MPI_CHAR,MPI_ANY_SOURCE,0,client,&status);
			MPI_Send((void *)strrev(msg),1024,MPI_CHAR,0,2,client);
		}
	}


}
