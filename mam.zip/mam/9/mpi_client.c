#include <mpi.h>
#include <stdio.h>
#include<string.h>

int main(int argc,char**argv)
{
	MPI_Comm server;
	char msg[1024];
	char port_name[MPI_MAX_PORT_NAME];

	MPI_Init(&argc,&argv);
	strcpy(port_name,argv[1]);
	MPI_Comm_connect(port_name,MPI_INFO_NULL,0,MPI_COMM_WORLD,&server);
	MPI_Status status;

	while(1)
	{
		printf("Enter a String :");
		scanf("%s",msg);
		MPI_Send(msg,1024,MPI_CHAR,0,0,server);
		MPI_Recv(msg,1024,MPI_CHAR,MPI_ANY_SOURCE,2,server,&status);
		printf("%s\n",msg);
	}
	MPI_Comm_disconnect(&server);
	MPI_Finalise();
	return 0;
}
