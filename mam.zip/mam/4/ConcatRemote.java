import java.rmi.*;
import java.rmi.server.*;

public class ConcatRemote extends UnicastRemoteObject implements Concat
{
	public ConcatRemote() throws RemoteException
	{
		super();
	}
	public String Concat(String x, String y)
	{
		return x+y;
	}
}
