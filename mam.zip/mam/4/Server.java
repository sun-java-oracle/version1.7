import java.rmi.*;
import java.rmi.registry.*;

public class Server{
	public static void main(String args[])
	{
		try{
		Concat stub = new ConcatRemote();
		Naming.rebind("rmi://192.168.5.144:5002/rmi",stub);
		System.out.println(""+stub);
		}
		catch(Exception e){System.out.println(e.toString());}
	}
} 
