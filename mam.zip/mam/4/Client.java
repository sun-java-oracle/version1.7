import java.rmi.*;
import java.util.*;
public class Client{
	public static void main(String args[])
	{
		try{
		Concat stub = (Concat)Naming.lookup("rmi://192.168.5.144:5002/rmi");
		Scanner in=new Scanner(System.in);
		System.out.println("Enter String 1 : ");
		String x = in.next();
		System.out.println("Enter String 2 : ");
		String y = in.next();
		System.out.println("Concatenated String : "+stub.Concat(x,y));
		}
		catch(Exception e){e.printStackTrace();}
	}
} 
