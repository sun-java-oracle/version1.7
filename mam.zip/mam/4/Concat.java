import java.rmi.*;

public interface Concat extends Remote
{
	public String Concat(String x,String y) throws RemoteException;
} 
