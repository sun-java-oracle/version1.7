import java.io.*;
import java.net.*;
import java.util.*;
public class Fact_Client
{
	public static void main(String args[])
	{
		String servername=args[0];
		int serverport=Integer.parseInt(args[1]);
		try
		{
			System.out.println("Connecting to server "+servername+" on port " +serverport);
			Socket client = new Socket(servername,serverport);
			System.out.println("Connected to server at "+client.getRemoteSocketAddress());
			Scanner input = new Scanner(System.in);
			System.out.println("Enter the Number");
			int num = input.nextInt();
			OutputStream outToServer = client.getOutputStream();
			DataOutputStream out = new DataOutputStream(outToServer);
			out.writeUTF(""+num);
			InputStream inFromServer = client.getInputStream();
			DataInputStream in = new DataInputStream(inFromServer);
			int fact = Integer.parseInt(in.readUTF());
			System.out.println("Factorial Received from Server "+fact);
			client.close();
		}
		catch(IOException e) {}	
	}
}
