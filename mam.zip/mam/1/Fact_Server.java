//Fact_Server.java

import java.io.*;
import java.net.*;

public class Fact_Server extends Thread
{
	private ServerSocket serversocket;
	public Fact_Server(int port)throws IOException
	{
		serversocket = new ServerSocket(port);
		serversocket.setSoTimeout(100000);
	}
	
	public void run()
	{
		while(true)
		{
			try
			{
				System.out.println("Server waiting on port "+serversocket.getLocalPort());
				Socket server = serversocket.accept();
				System.out.println("Just connected to : "+server.getRemoteSocketAddress());
				DataInputStream in = new DataInputStream(server.getInputStream());
				int num = Integer.parseInt(in.readUTF());
				int Fact = 1;
				for(int i=1;i<=num;i++)
					Fact*=i;
				DataOutputStream out = new DataOutputStream(server.getOutputStream());
				out.writeUTF(""+Fact);
				System.out.println("Received num = "+num+"\tReturned Fact = "+Fact);
			}
			catch(IOException e){break;}
		}
	}

	public static void main(String args[])	
	{
		int port = Integer.parseInt(args[0]);
		try
		{
			Thread t = new Fact_Server(port);
			t.start();
		}
		catch(IOException e){}
		
	}
}
