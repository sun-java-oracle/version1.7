#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<mpi.h>

int main(int argc, char **argv)
{
	MPI_Comm server;
	MPI_Status status;
	char port_name[MPI_MAX_PORT_NAME];
	char msg[1024];
	char size[1024];

	MPI_Init(&argc,&argv);
	strcpy(port_name,argv[1]);
	MPI_Comm_connect(port_name,MPI_INFO_NULL,0,MPI_COMM_WORLD,&server);
	
	while(1)
	{
		printf("Enter the String");
		scanf("%s",msg);
		MPI_Send(msg,1024,MPI_CHAR,0,0,server);
		MPI_Recv(size,1024,MPI_INT,MPI_ANY_SOURCE,2,server,&status);
		printf("Size = %s\n",size);
	}
	MPI_Comm_disconnect(&server);
	MPI_Finalise();
	return 1;
}
