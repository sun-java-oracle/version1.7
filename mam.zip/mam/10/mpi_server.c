#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<mpi.h>

int main(int argc, char **argv)
{
	printf("sdv");
		
	MPI_Comm client;
	MPI_Status status;
	char port_name[MPI_MAX_PORT_NAME];
	int size;
	char msg[1024];
	
	
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD,&size);
	if(size != 1)
		perror("Server too big");
	MPI_Open_port(MPI_INFO_NULL,port_name);
	printf("Server running on %s:",port_name);
	while(1)
	{
		MPI_Comm_accept(port_name,MPI_INFO_NULL,0,MPI_COMM_WORLD,&client);
		while(1)
		{
			MPI_Recv(msg,1024,MPI_CHAR,MPI_ANY_SOURCE,0,client,&status);
			MPI_Send((void*)strlen(msg),1024,MPI_INT,0,2,client);
		}
	}
}
