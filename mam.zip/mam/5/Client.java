import java.rmi.*;
import java.util.*;

public class Client
{
	public static void main(String args[])
	{
		try{
		Square stub=(Square)Naming.lookup("rmi://192.168.5.144:5002/rmi");
		Scanner in =new Scanner(System.in);
		System.out.println("Enter the no.");
		int num = in.nextInt();
		int x = stub.Square(num);
		System.out.println("Square of the no. is "+x);
		}
		catch(Exception e){System.out.println(e.toString());}
	}
}
