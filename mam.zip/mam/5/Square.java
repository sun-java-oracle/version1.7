import java.rmi.*;

public interface Square extends Remote
{
	public int Square(int x)throws RemoteException;
}
