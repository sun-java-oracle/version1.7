import java.rmi.*;
import java.rmi.server.*;

public class SquareRemote extends UnicastRemoteObject implements Square
{
	public SquareRemote()throws RemoteException
	{
		super();
	}
	public int Square(int x) 
	{
		int y = x*x;
		return y;
	}
} 
