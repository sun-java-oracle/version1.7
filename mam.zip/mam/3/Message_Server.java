import java.io.*;
import java.net.*;

public class Message_Server extends Thread
{
	private ServerSocket serversocket;
	public Message_Server(int port)throws IOException
	{
		serversocket=new ServerSocket(port);
		serversocket.setSoTimeout(100000);
	}

	public void run()
	{
		while(true)
		{
			try{
				System.out.println("Waiting for connection at port "+serversocket.getLocalPort());
				Socket server=serversocket.accept();
				System.out.println("Connected to :"+server.getRemoteSocketAddress());
				DataInputStream in = new DataInputStream(server.getInputStream());
				DataOutputStream out = new DataOutputStream(server.getOutputStream());
				System.out.println("Receiving messages from Client");
				String inp;
				while(!(inp=in.readUTF()).equals("Exit"))
					System.out.println(""+inp);
			}
		catch(IOException e){break;}
		}
	}
	
	public static void main(String args[])
	{
		try
		{
			Thread  t = new Message_Server(Integer.parseInt(args[0]));
			t.start();
		}
		catch(IOException e){}
	}
}
