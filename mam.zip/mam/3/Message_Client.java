import java.io.*;
import java.net.*;
import java.util.*;
public class Message_Client
{
	public static void main(String args[])
	{
		String servername = args[0];
		int port = Integer.parseInt(args[1]);
		try{
			System.out.println("Connecting to server "+servername+" at port "+port);
			Socket client = new Socket(servername,port);
			System.out.println("Connected to "+client.getRemoteSocketAddress());
			DataInputStream in = new DataInputStream(client.getInputStream());
			DataOutputStream out = new DataOutputStream(client.getOutputStream());
			Scanner input = new Scanner(System.in);
			System.out.println("Enter String to send to server");
			String msg = input.next();
			do
			{
				out.writeUTF(""+msg);
				System.out.println("Message sent to server");
				System.out.println("Enter String to send to server");
				msg = input.next();
			
			}while(!msg.equals("Exit"));
			client.close();
		}
		catch (IOException e) {}
	}
}
