import java.rmi.*;

public interface Adder extends Remote
{
	public int Adder(int x, int y) throws RemoteException;
}
