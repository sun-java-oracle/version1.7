import java.rmi.*;
import java.rmi.registry.*;

public class Server
{
	public static void main(String args[])
	{
		try{
			Adder stub = new AdderRemote();
			Naming.rebind("rmi://192.168.5.144:5002/rmi",stub);
		}
		catch(Exception e){System.out.println(e.toString());}
	}
}
