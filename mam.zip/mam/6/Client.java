import java.rmi.*;
import java.util.*;

public class Client
{
	public static void main(String args[])
	{
		try{
			Adder stub = (Adder)Naming.lookup("rmi://192.168.5.144:5002/rmi");
			Scanner in = new Scanner(System.in);
			System.out.println("Enter the 2 nos");
			int x = in.nextInt();
			int y = in.nextInt();
			System.out.println("Addition : "+stub.Adder(x,y));
		}
		catch(Exception e){System.out.println(e.toString());}
	}
}
